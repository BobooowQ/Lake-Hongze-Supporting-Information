clear;clc;close all;
%% description:
%  hindcast runs are based on Figure2.m 
%  hindcast inputs are from "hindcast" from "Data.xlsx"
%  hindcast results are in hindcast.mat
%  hindcast temporal result will show in Figure3A
%  Figure3B will be finished from Amos
%% Figure3A
load hindcast
aasce=scenario;%hindcast results
% calculate monthly averages
for i=1:2
    for j=1:2
        for h=1:round(size(aasce{1,1},1)/(365/12))
            aasce0{i,j}(h,1:size(aasce{1,1},2))=...
                mean(aasce{i,j}(h*30-29:h*30,1:size(aasce{1,1},2)));
        end
        for h=1:round(size(aasce{1,1},1)/365)
            aasce1{i,j}(h,1:size(aasce{1,1},2))=...
                mean(aasce{i,j}(h*365-364:h*365,1:size(aasce{1,1},2)));
        end
    end
end
unit={'g�m^-^3','g�m^-^3','g�m^-^3','m',...
    '%','mg�m^-^3','g�m^-^2','g�m^-^2','g�m^-^3'};
name={'Total nitrogen','Total phosphorus','Dissolved oxygen',...
    'Secchi depth','Macrophyte coverage','Chlorophyll-a',...
    'Zoobenthos','Total fish','Zooplankton'};
px=0.047;
py=0.08;
px1=0.145;
py1=0.4;
close all
code1=[1 2 4 5 6 7 8 9];
load mycolor
col=color.C3;
figure
set(gcf,'color','w')
for i=1:size(code1,2)
    xx1=i-fix(i/4.1)*4;
    yy1=fix(i/4.1);
    subplot('Position',[xx1*px+(xx1-1)*px1,0.57-yy1*(py1+py),px1,py1])
    for j=1:2
        plot(aasce0{1,j}(:,1)/365+2015,aasce0{1,j}(:,1+code1(i)),'.','color',col(j,:),'markersize',5)
        hold on
        clear n x y b yfit
        x=aasce1{1,j}(:,1)/365+2015;
        y=aasce1{1,j}(:,1+code1(i));
        yfit = smooth(x, y, 0.5, 'lowess'); 
        plot(x,yfit,'-','color',col(j,:),'linewidth',2)
        hold on
    end
    set(gca,'box','off')
    ylabel(char(unit{code1(i)}))
    set(gca,'fontsize',8)
    if i==8
        ll=legend({'FB montly','FB annual',...
            'No FB montly','No FB annual'});
        set(ll,'box','off','location','northeast','orientation','vertical')
        set(ll,'fontsize',10)
        ll.ItemTokenSize = [5,3];
    end
    xlim([2020,2024])
    set(gca, 'XTick', 2020:2:2024);
    yl=ylim;
    tt1=text(2020.2,yl(1)+(yl(2)-yl(1))*0.98,char(name{code1(i)}));
    set(tt1,'fontsize',10,'fontweight','bold')   
    if i==7
        tt1=text(2019.5,yl(1)-(yl(2)-yl(1))*0.15,'Time');
        set(tt1,'fontsize',8,'fontweight','bold')
    end
end
set(gcf, 'Units', 'inches', 'Position', [0.5 0.5 10 4]);
%% export data for SEM analysis using Amos
x=aasce0{1,1}(54:108,:);
fp11 = fopen('data4sem1.sav','wt');
  for i = 1 : size(x,1)
      for j=1:size(x,2)
     fprintf(fp11, '%f,', x(i,j));
      end
  end
 fclose(fp11);
x=aasce0{1,2}(54:108,:);
fp11 = fopen('data4sem2.sav','wt');
  for i = 1 : size(x,1)
      for j=1:size(x,2)
     fprintf(fp11, '%f,', x(i,j));
      end
  end
 fclose(fp11);
 
 