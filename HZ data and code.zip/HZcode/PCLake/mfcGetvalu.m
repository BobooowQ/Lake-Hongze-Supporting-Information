function n3=mfcGetvalu(tabel,c1,n1,c3)

%%
for i=1:size(tabel,1)
    if ismember(tabel(i,c1),str2cell(n1))==1
            n3=tabel{i,c3};
            break
    end
end
