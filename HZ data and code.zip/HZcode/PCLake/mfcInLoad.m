function data=mfcInLoad(data)
%loaddata
data0={'mTemp'
'mLOut'
'mQIn'
'mQEv'
'mQOut'
'mVWind'
'mPLoad'
'mNLoad'
'mDLoadDet'
'mDLoadIM'
'mPLoadPhyt'
'mPLoadPO4'
'mPLoadOrg'
'mNLoadNH4'
'mNLoadNO3'
'mNLoadOrg'
'mkHarvFishSum'
'mkHarvFishWin'
'mkHarvPiscSum'
'mkHarvPiscWin'
'mDFiJv'
'mDFiAd'};
data0(:,2)=num2cell(1:size(data0,1))';

for i=1:size(data,1)
    id=data0{find(ismember(data0(:,1),data{i,1})),2};
switch id
case 1
loaddata mTemp.txt
case 2
loaddata mLOut.txt
case 3
loaddata mQIn.txt
case 4
loaddata mQEv.txt
case 5
loaddata mQOut.txt
case 6
loaddata mVWind.txt
case 7
loaddata mPLoad.txt
case 8
loaddata mNLoad.txt
case 9
loaddata mDLoadDet.txt
case 10
loaddata mDLoadIm.txt
case 11
loaddata mPLoadPhyt.txt
case 12
loaddata mPLoadPO4.txt
case 13
loaddata mPLoadOrg.txt
case 14
loaddata mNLoadNH4.txt
case 15
loaddata mNLoadNO3.txt
case 16
loaddata mNLoadOrg.txt
case 17
loaddata mkHarvFishSum.txt
case 18
loaddata mkHarvFishWin.txt
case 19
loaddata mkHarvPiscSum.txt
case 20
loaddata mkHarvPiscWin.txt
case 21
loaddata mDFiJv.txt
case 22
loaddata mDFiAd.txt
end

end

