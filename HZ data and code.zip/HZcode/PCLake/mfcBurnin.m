function data2 = mfcBurnin(data,time)

%%
data1=data(data(:,1)<365,:);
code=size(data1,1);
if time>1
    data2=data1;
for i=2:time
    data2(i*code-code+1:i*code,:)=data1;
    data2(i*code-code+1:i*code,1)=...
        data2((i-1)*code-code+1:(i-1)*code,1)+365;
end
else
    data2=data1;
end
data3=data;
data3(:,1)=data3(:,1)+data2(end,1)+data3(end,1)-data3(end-1,1);
data2=[data2;data3];


%%

end

