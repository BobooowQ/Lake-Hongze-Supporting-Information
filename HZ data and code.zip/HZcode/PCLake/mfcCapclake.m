function ModelFit = mfcCapclake(paravalue,method,states,ifshow,methodshow)
% paravalue: values of parameters that need to be calibrated automatically
% method: use which index to auto calibration
% states: use which model output to calculate method
% ifshow: if show the output with observations
% method show: which other two mehods to show in the fig

%% load data and model
load a0
data=paravalue;
for i=1:size(a0.paracali,1)
    a0.parameter{find(ismember(a0.parameter(:,1),a0.paracali(i,1))),2}=data(i);
end
mfcInModel(a0.model);%load model
a0.read=a0.readv;
mfcAssign(a0.initial);%initial state
mfcAssign(a0.parameter);%calibrated parameters
mfcAssign(a0.case);%case speciality
inputread=a0.read(:,6);%readxxx=1
inputread(:,2)={[1]};
mfcAssign(inputread);%readxxx=1
input=a0.read(:,[2,10]);
mfcInLoad(input);%loaddata xxx
compare=a0.compare(:,2);

%% calibrate parameters
% Pbias=1,RMSE=2,HH=3,RSR=4,MAE=5,PCC=6,R2=7,NSE=8,KGE=9,NRMSE=10
methodname={'Pbias','RMSE','HH','RSR','MAE','PCC','R^2','NSE','KGE','NRMSE'};
methodunit=[1,1,1,1,1,-1,-1,-1,-1,1];
maxtim=35;
tic
while true
    try
        simtime 0 a0.TT a0.TT
        csolvers -c
        solver c.ode45
        out(compare{:});
        % model output->x
        x=time;
        x=x(a0.burnyr*365+1:end,:);
        x(:,1)=x(:,1)-x(1,1);
        % get model evaluation
        for i=1:size(a0.compare,1)
            a0.compare{i,9}(a0.compare{i,9}(:,1)<a0.startyr,:)=[];
            a0.compare{i,9}(a0.compare{i,9}(:,1)>a0.endyr+1,:)=[];
            time1=(a0.compare{i,9}(:,1)-a0.startyr)*365;
            resolution=a0.compare{i,3};
            data1=x(:,i+1);
            a0.compare{i,9}(:,3)=mfcFindmean(time1,resolution,data1);
            data=a0.compare{i,9}(:,2:3);
            data(max(isnan(data)'),:)=[];
            Qs=data(:,2);
            Qo=data(:,1);
            % get chosen index of comparison
            data2(i)=mfcEvalRE(Qs,Qo,method); 
            % get all index of comparison
            if ifshow==1
                for z=1:10
                    datashow(i,z)=mfcEvalRE(Qs,Qo,z);
                end
            end
            % get all index of comparison
        end
        funcout=mean(data2(states))*methodunit(method); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ifshow=1: plot sim.v.s.obs.
if ifshow==1&&isnan(funcout)==0
code={'1','Pbias','Percent bias','<+-15,best=0';...
'2','RMSE','RMSE','best=0';...
'3','HH','Hanna and Heinold indicator','best=0';...
'4','RSR','RMSE/sqrt(TSS)','[0,+),better<0.7';...
'5','MAE','MAE','best=0';...
'6','PCC','Pearson correlation coefficient','(-1,1),best=1';...
'7','R2','Coefficient of Determination','[0,1],better>0.6';...
'8','NSE','the Nash-Sutcliffe efficiency coefficient','(-,1],better>0.5';...
'9','KGE','Kling-Gupta efficiency coefficient','(-,1)';...
'10','NRMSE','NRMSE','best=0'};
data3=a0.compare(:,[2,5]);
data3(:,3)=num2cell(data2');
data3(end+1,2)={'mean value'};
data3(end,3)=num2cell(funcout);
data3(end+1,1:3)=code(find(cell2num(code(:,1))==method),2:4);
data3(1:size(a0.compare,1),4)=a0.compare(:,9);
data3{1,5}=datashow;
close all
load aobs
load mycolor
col=color.C1;
code1=methodshow;
% figure (2)
% set(gcf,'color','w')
% for i=1:size(a0.compare,1)
%     subplot(3,3,i)
%     for j=1:size(aobs,2)-8
%     plot(aobs{i,8+j}(:,1),aobs{i,8+j}(:,2),'-','color',col(j,:))
%     hold on
%     end
%     plot(a0.compare{i,9}(:,1),a0.compare{i,9}(:,3),'r','linewidth',2)
%     hold on
%     plot(x(:,1)/365+a0.startyr,x(:,i+1),'.k','markersize',2)
%     hold on
%     xlim([a0.startyr,a0.endyr])
%     ylabel(char(a0.compare{i,2}))
%     title([char(methodname{method}), num2str(roundn(data3{i,3},-2)),...
%         ',  ',char(methodname{code1(1)}),num2str(roundn(datashow(i,code1(1)),-2)),...
%         ',  ',char(methodname{code1(2)}),num2str(roundn(datashow(i,code1(2)),-2))]);
%     if i==size(a0.compare,1)
%         ll=legend({'whole lake','open','chengzi','lihewa','model'});
%         set(ll,'box','off','location','best')
%     end
% end
% set(gcf, 'Units', 'inches', 'Position', [0.5 0.8 15 7]); 
% % set(gca, 'LooseInset', get(gca, 'TightInset'));
% suptitle(['Average= ', num2str(roundn(funcout,-2)*methodunit(method))]); 
data3{1,6}=x;
ModelFit=data3;
else
    ModelFit=funcout
end      
    return
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% if model can not run
    catch ME
        disp("!!!!!!!!!!!!! Model error !!!!!!!!!!!!!")
        ModelFit=nan
        return
        
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% if simulation takes too long
    if toc>maxtim
        disp("!!!!!!!!!!!!! Time is out !!!!!!!!!!!!!")
        toc
        ModelFit=nan
        return
    end
    
break
    
end

%%
end

