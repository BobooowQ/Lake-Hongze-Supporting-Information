function data=mfcInModel(name)
%%
dt=find(ismember({'PCLake','PCLakeHZ'},name));

switch dt
    case 1;use PCLake.ini        
    case 2;use PCLakeHZ.ini
end

%%
end

