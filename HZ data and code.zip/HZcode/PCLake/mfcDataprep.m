function data = mfcDataprep(xlsname,control,parameter,initial,read,obs,zone)

%read data from excel AtrData and save in a0 (model data)
%   Detailed explanation goes here

%% model; time; case
[~,~,cont]=xlsread(xlsname,control);
a0.model=mfcGetname(cont,3,'model',12,1,5);
a0.parameter=mfcGetname(cont,3,'parameter',12,1,5);
a0.initial=mfcGetname(cont,3,'initial',12,1,5);
a0.startyr=mfcGetvalu(cont,3,'startyr',12);
a0.endyr=mfcGetvalu(cont,3,'endyr',12);
a0.burnyr=mfcGetvalu(cont,3,'burnyr',12);
a0.case=cont(find(strcmp(cont(:,3),'case')),[5,12]);
a0.TT=(a0.endyr-a0.startyr+a0.burnyr)*365;


%% read
[~,~,mydatacell]=xlsread(xlsname,read);
dname=mydatacell(1,:);
datacell=mydatacell(2:end,:);
data1=ones(size(datacell))*nan;
for ii=1:size(datacell,2)
data=datacell(:,ii);
data=cell2mat(data);
data1(1:size(data,1),ii)=data;
end
data=data1;
code=[3 5 9 12 4 7 13 14];%column code
for i=1:length(code)
x(:,i)=cont(find(strcmp(cont(:,3),'read'))',code(i));
end
for i=1:size(x,1)
    data0=data(:,[find(ismember(dname,x(i,2)))-1,...
        find(ismember(dname,x(i,2)))]);
    if size(data0,2)==2
        data0(isnan(data0(:,2))==1,:)=[];
        data0(data0>a0.endyr*365,:)=[];
    end
    x{i,length(code)+1}=data0;
end
a0.readv=x(cell2num(x(:,4))==1,:);
a0.readt=x(cell2num(x(:,4))==2,:);

%% compare
[~,~,mydatacell]=xlsread(xlsname,obs);
dname=mydatacell(1,:);
datacell=mydatacell(2:end,:);
data1=ones(size(datacell))*nan;
for ii=1:size(datacell,2)
data=datacell(:,ii);
data=cell2mat(data);
data1(1:size(data,1),ii)=data;
end
data=data1;
for i=1:length(code)
    y(:,i)=cont(find(strcmp(cont(:,3),'compare'))',code(i));
end

for i=1:size(y,1)
    data0=data(:,...
        find(ismember(dname,y(i,2)))-3:find(ismember(dname,y(i,2))));
    if isempty(data0)==0
    data0(isnan(data0(:,4))==1,:)=[];
    data1=data0(data0(:,3)==zone,:);
    data1(:,1)=data1(:,1)+(data1(:,2)-0.5)/12;
    data1=data1(:,[1,4]);
    y{i,length(code)+1}=data1;
    end
end
a0.compare=y(cell2num(y(:,4))>0,:);


%% initial; parameter
[~,~,para]=xlsread(xlsname,parameter);
para(1,:)=[];
para=para(:,4:6);
a0.parameter=para;
a0.paracali=a0.parameter;
[~,~,init]=xlsread(xlsname,initial);
codenew=find(ismember(string(init(1,:)), string(str2cell(a0.initial))));
init=init(:,[4,codenew]);
init(1,:)=[];
a0.initial=init;

%% save
% save('a0.mat','a0')
data=a0;
%%
end

