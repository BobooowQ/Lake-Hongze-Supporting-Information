clear;clc;close all;
%% description:
%  scenario runs are based on Figure2.m 
%  scenario inputs are from "scenarios" from "Data.xlsx"
%  scenario results are in scenarios.mat
%  scenario result will show in Figure4
%% Figure4
load scenarios
aasce=scenario;
for i=1:2
    for j=1:4
        for h=1:round(size(aasce{1,1},1)/31)
            aasce0{i,j}(h,1:size(aasce{1,1},2))=...
                mean(aasce{i,j}(h*30-29:h*30,1:size(aasce{1,1},2)));
        end
        for h=1:round(size(aasce{1,1},1)/365)
            aasce1{i,j}(h,1:size(aasce{1,1},2))=...
                mean(aasce{i,j}(h*365-364:h*365,1:size(aasce{1,1},2)));
        end
        for h=1:9
            clear data
            data=aasce1{i,j}(:,h+1)./aasce1{1,1}(:,h+1);
            aasceRatio{h}(i,j)=data(end,1);%compared to fish ban+current nutrient control
        end
    end
end
% figure heatmap
unit={'g�m^-^3','g�m^-^3','g�m^-^3','m',...
    '%','mg�m^-^3','g�m^-^3','g�m^-^2','g�m^-^3'};
name={'Total nitrogen','Total phosphorus','Dissolved oxygen',...
    'Secchi depth','Macrophyte coverage','Chlorophyll-a',...
    'Zoobenthos','Total fish','Zooplankton'};
code=[1 3 4 2 6 5 8 9 7];
aasceRatio1=aasceRatio(code);
name1=name(code);
unit1=unit(code);
px=0.1;
py=0.1;
px1=0.2;
py1=0.2;
figure
set(gcf,'color','w')
for i=1:9
    xx1=i-fix(i/3.1)*3;
    yy1=fix(i/3.1);
    subplot('Position',[xx1*px+(xx1-1)*px1,0.7-yy1*(py1+py),px1,py1])
    data=aasceRatio1{i};
    h=heatmap(data,'ColorbarVisible','on');
    title(char(name1{i}));
    colormap(othercolor('BrBG7'));
    h.CellLabelFormat = '%.2f';
    set(gca,'FontSize',8); 
    ax = gca;
    ax.XData = ['F0' "F0/1" "F0.5" 'F1'];
    ax.YData = ['NP-' "NP--"];
    title(char(name1{i}));
end
set(gcf, 'Units', 'inches', 'Position', [0.5 0.5 10 5]);












