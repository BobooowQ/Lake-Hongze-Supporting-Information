function data=mfcInExport(data)
%exportation
h=size(data,1);

for i=1:h
    data1=data{i,2};
%     data1(:,1)=(data1(:,1)-data1(1,1))*365;%
    filename =strcat(data{i,1},'.txt');
    fid=fopen(char(filename),'w+');
    fprintf(fid,'%s %s\n','t',char(data{i,1}));
    for m=1:size(data1,1)
        for n=1:2
            fprintf(fid,'%f\t',data1(m,n));
        end
        fprintf(fid,'\r\n');
    end
    fclose(fid);
end

end

