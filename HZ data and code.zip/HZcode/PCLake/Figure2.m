clear;clc;close all;
%% description:
%  part 1: use data from "Data.xlsx" to run model
%  part 2: show result in Figure 2 
%% part 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% get setting and data from excel for the model 
xlsname='Data.xlsx';%excel name
control='PCLakeHZ';%sheet name #############################
parameter='parameter';%sheet name
initial='initial';%sheet name
read='read';%sheet name
obs='observe';%sheet name
zone=1;%choose zone for comparison
a0=mfcDataprep(xlsname,control,parameter,initial,read,obs,zone);
a0=mfcInputv(a0);% export inputs to txt
save('a0.mat','a0')% save prepared data
% get observation of different zones
zone=1;a01=mfcDataprep(xlsname,control,parameter,initial,read,obs,zone);
zone=2;a02=mfcDataprep(xlsname,control,parameter,initial,read,obs,zone);
zone=3;a03=mfcDataprep(xlsname,control,parameter,initial,read,obs,zone);
zone=4;a04=mfcDataprep(xlsname,control,parameter,initial,read,obs,zone);
aobs=a01.compare;
aobs(:,8+2)=a02.compare(:,9);
aobs(:,8+3)=a03.compare(:,9);
aobs(:,8+4)=a04.compare(:,9);
save('aobs.mat','aobs')
% run model and get data for visualization
paravalue=cell2mat(a0.parameter(:,3));% use default or calibrated value #############################
method=2;%Pbias=1,RMSE=2,HH=3,RSR=4,MAE=5,PCC=6,R2=7,NSE=8,KGE=9,NRMSE=10
states=1:1:8;ifshow=1;
methodshow=[7,2];%Pbias=1,RMSE=2,HH=3,RSR=4,MAE=5,PCC=6,R2=7,NSE=8,KGE=9,NRMSE=10
ModelFit=mfcCapclake(paravalue,method,states,ifshow,methodshow);
x=ModelFit{1,6};%model output
datashow=ModelFit{1,5};%comparisn between simulation and observation
%% part 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
close all
load aobs
load mycolor
col=color.C3;
code={'1','Pbias','Percent bias','<+-15,best=0';...
'2','RMSE','RMSE','best=0';...
'3','HH','Hanna and Heinold indicator','best=0';...
'4','RSR','RMSE/sqrt(TSS)','[0,+),better<0.7';...
'5','MAE','MAE','best=0';...
'6','PCC','Pearson correlation coefficient','(-1,1),best=1';...
'7','R^2','Coefficient of Determination','[0,1],better>0.6';...
'8','NSE','the Nash-Sutcliffe efficiency coefficient','(-,1],better>0.5';...
'9','KGE','Kling-Gupta efficiency coefficient','(-,1)';...
'10','NRMSE','NRMSE','best=0'};
code1=[7,2];
unit={'g�m^-^3','g�m^-^3','g�m^-^3','m',...
    '%','mg�m^-^3','g�m^-^2','g�m^-^2�d^-^1'};
name={'Total nitrogen','Total phosphorus','Dissolved oxygen',...
    'Secchi depth','Macrophyte coverage','Chlorophyll-a',...
    'Zoobenthos','Fish catch'};
x1=x(1:365*4,:);
px=0.047;
py=0.08;
px1=0.145;
py1=0.4;
figure
set(gcf,'color','w')
for i=1:size(a0.compare,1)
    xx1=i-fix(i/4.1)*4;
    yy1=fix(i/4.1);
    subplot('Position',[xx1*px+(xx1-1)*px1,0.57-yy1*(py1+py),px1,py1])
    hold on
    for j=2:size(aobs,2)-8
        % plot all observations
        p1=plot(aobs{i,8+j}(:,1),aobs{i,8+j}(:,2),'.','color',col(1,:),'markersize',8)
        hold on
    end
    % plot model outputs
    p2=plot(x1(:,1)/365+a0.startyr,x1(:,i+1),'-','color',col(2,:),'linewidth',2);
    hold on
    set(gca,'box','off')
    ylabel(char(unit{i}))
    set(gca,'fontsize',8)
    if i==size(a0.compare,1)
        ll=legend([p1,p2],{'Observed','Simulated'});
        set(ll,'box','off','location','northeast','orientation','vertical')
        set(ll,'fontsize',10)
        ll.ItemTokenSize = [5,3];
    end
    xlim([a0.startyr,a0.endyr])
    yl=ylim;
    ylim([yl(1),yl(2)*1.2])
    yl=ylim;
    tt1=text(2016.2,yl(1)+(yl(2)-yl(1))*0.98,char(name{i}));
    set(tt1,'fontsize',10,'fontweight','bold')
    tt=text(2016.2,yl(1)+(yl(2)-yl(1))*0.85,...
        [char(code{code1(1),2}),' = ', num2str(roundn(datashow(i,code1(1)),-2)),...
        sprintf('\n'),...
        char(code{code1(2),2}),' = ', num2str(roundn(datashow(i,code1(2)),-2))]);
    set(tt,'fontsize',8)
    if i==6
        tt1=text(2021,yl(1)-(yl(2)-yl(1))*0.15,'Time');
        set(tt1,'fontsize',8,'fontweight','bold')
    end
    ylim(yl)
end
set(gcf, 'Units', 'inches', 'Position', [0.5 0.5 10 4]);
