function data=mfcAssign(data)
%exportation
%%
name=data(:,1);
value=cell2mat(data(:,2));

for i=1:size(name,1)
    a=libpointer('string',name{i,1});
    b=libpointer('doublePtrPtr',value(i,1));
    assignin('base',get(a,'Value'), get(b,'Value'));
end
%%
end

