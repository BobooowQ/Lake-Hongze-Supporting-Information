function data2 = mfcFindmean(time,resolution,data1)

data=time;
n=find(ismember({'annual','month','day'},resolution)==1);

if n==1
    type=365;
else if n==2
        type=31;
    else
        type=1;    
    end
end

%%
for i=1:size(data,1)
    nn1=round(max(data(i,1)+round(type/2),0));
    nn2=round(min(data(i,1)+type,size(data1,1)));
    data2(i,1)=mean(data1(nn1:nn2,1));
end

%%
end

