function data5 = mfcInputReso(aresol,adata)
%%
%interpolation and duplication of model input
if strcmp(aresol,'day')
    type=1;
else if strcmp(aresol,'month')
        type=2;
    else
        type=3;    
    end
end

%%
switch type
    
case 1
data5=adata(1,:);
for i=2:size(adata,1)
    if adata(i,1)-adata(i-1,1)>1
        x=adata(i-1:i,1);
        y=adata(i-1:i,2);
        xi=x(1):1:x(2);
        yi=interp1(x,y,xi,'spline');
        data5=[data5;xi',yi'];
    else
        data5=[data5;adata(i,:)];
    end        
end

case 2
data5=adata(1,:);
for i=2:size(adata,1)
    if adata(i,1)-adata(i-1,1)>30
        x=adata(i-1:i,1);
        y=adata(i-1:i,2);
        xi=x(1):30:round((x(2)-x(1))/30)*30+x(1);
        yi=interp1(x,y,xi,'spline');
        data5=[data5;xi',yi'];
    else
        data5=[data5;adata(i,:)];
    end        
end

case 3
data5=adata(1,:);
for i=2:size(adata,1)
    if adata(i,1)-adata(i-1,1)>365
        x=adata(i-1:i,1);
        y=adata(i-1:i,2);
        xi=x(1):365:round((x(2)-x(1))/365)*365+x(1);
        yi=interp1(x,y,xi,'spline');
        data5=[data5;xi',yi'];
    else
        data5=[data5;adata(i,:)];
    end        
end
        
end

%%
data5=sortrows(data5,1);
data5(find(round((data5(2:end,1)-data5(1:end-1,1)))==0)+1,:)=[];

end

