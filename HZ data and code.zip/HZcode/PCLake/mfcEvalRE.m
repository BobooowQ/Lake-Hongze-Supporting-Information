function data = mfcEvalRE(Qs,Qo,method)
% https://blog.csdn.net/qq_44246618/article/details/128999913
% Moriasi et al.?2007?
%%
% Pearson's correlation coefficient, PCC
COV = cov(Qs,Qo);
PCC = COV(1,2)/std(Qs)/std(Qo);
% Percent bias, Pbias
Qs_avg = mean(Qs);
Qo_avg = mean(Qo);
Pbias = (Qs_avg -Qo_avg )/Qo_avg *100;
% the Nash-Sutcliffe efficiency coefficient, NSE
QoAve = mean(Qo);
NSE = 1- sum( (Qs-Qo).^2 )/sum( (Qo-QoAve).^2 );
% Kling-Gupta efficiency coefficient, KGE
QsAve = mean(Qs);
QoAve = mean(Qo);
COV = cov(Qs, Qo);
CC = COV(1,2)/std(Qs)/std(Qo);
BR = QsAve/QoAve;
RV = ( std(Qs)/QsAve )/ ( std(Qo)/QoAve );
KGE = 1- ( (CC-1)^2+(BR-1)^2+(RV-1)^2 )^0.5;
% Coefficient of Determination R2
QsAve = mean(Qs);
QoAve = mean(Qo);
tempX = sum( (Qo-QoAve).*(Qs-QsAve));
tempY = sum( (Qo-QoAve).^2 )^0.5 * sum( (Qs-QsAve).^2)^0.5 ;
R2 = tempX/tempY;
% RMSE
RMSE=sqrt(mean((Qs-Qo).^2));
% RMSE
NRMSE=RMSE/mean(Qo);

% RSR: RMSE/sqrt(TSS)
QoAve = mean(Qo);
RSR = ( sum(Qo-Qs).^2 )^0.5/( sum(Qo-QoAve).^2 )^0.5;
% HH: Mentaschi et al. 2013 - Why NRMSE is not completely reliable
% Mentaschi et al. Problems in RMSE-based wave model validations. August 2013. Ocean Modelling 72:53-58.DOI: 10.1016/j.ocemod.2013.08.003
% Hanna and Heinold (1985) indicator
HH=(sum(Qs-Qo).^2/sum(Qs.*Qo))^0.5;
% MAE
MAE = sum(abs(Qs-Qo))/size(Qs,1);
%
RE.Pbias=Pbias;%<+-15%,best=0
RE.RMSE=RMSE;%best=0
RE.HH=HH;%best=0
RE.RSR=RSR;%[0,+),better<0.7
RE.MAE=MAE;
RE.PCC=PCC;%(-1,1),best=1
RE.R2=R2;%[0,1],better>0.6
RE.NSE=NSE;%>(-,1],better0.5
RE.KGE=KGE;%(-,1)
RE.NRMSE=NRMSE;

switch method
    case 1
        data=RE.Pbias;
    case 2
        data=RE.RMSE;
    case 3
        data=RE.HH;
    case 4
        data=RE.RSR;
    case 5
        data=RE.MAE;
    case 6
        data=RE.PCC;
    case 7
        data=RE.R2;
    case 8
        data=RE.NSE;
    case 9
        data=RE.KGE;
    case 10
        data=RE.NRMSE;
end
       

















%%
end

