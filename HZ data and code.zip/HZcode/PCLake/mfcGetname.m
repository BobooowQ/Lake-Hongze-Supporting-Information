function n3=mfcGetname(tabel,c1,n1,c2,n2,c3)

%%
for i=1:size(tabel,1)
    if ismember(tabel(i,c1),str2cell(n1))==1
        if isequal(cell2num(tabel(i,c2)),n2)==1
            n3=tabel{i,c3};
            break
        end
    end
end



%%
end


