function data1=mfcInputv(data)
%INPUTV Summary of this function goes here
% inputs using true values

a0=data;
%%
for i=1:size(a0.readv,1)
    aresol=a0.readv{i,3};
    adata=a0.readv{i,9};
    adata(:,1)=(adata(:,1)-a0.startyr)*365;
    a0.readv{i,10}=mfcInputReso(aresol,adata);%resolution
    time=a0.burnyr;
    a0.readv{i,10}=mfcBurnin(a0.readv{i,10},time);%burn in
    data=a0.readv(i,[2,10]);
    mfcInExport(data);%export to txt
end
data1=a0;
%%
end

